import express from 'express';
import axios from 'axios';


interface JiraFields {
  summary?: string;
  description?: string;
  customfield_10016?: string;
  customfield_10017?: string;
}

interface JiraResponse {
  fields: JiraFields;
}

const JIRA_API_BASE = (process.env.JIRA_API_BASE || 'https://genai-testing-demo.atlassian.net').replace(/\/+$/, '');

// Use functions to get the latest values from process.env
const getJiraEmail = () => process.env.JIRA_EMAIL;
const getJiraToken = () => process.env.JIRA_API_TOKEN;

// Note: environment variables are expected to be loaded by the server before importing this module.

export const jiraRouter = express.Router();

jiraRouter.get('/:storyId', async (req: express.Request, res: express.Response): Promise<void> => {
  try {
    const { storyId } = req.params;
    const jiraEmail = getJiraEmail();
    const jiraToken = getJiraToken();

    console.log('Fetching story:', storyId);
    console.log('Using Jira credentials:', {
      JIRA_API_BASE,
      hasEmail: !!jiraEmail,
      emailLength: jiraEmail?.length || 0,
      hasToken: !!jiraToken,
      tokenLength: jiraToken?.length || 0
    });
    
    if (!jiraEmail || !jiraToken) {
      console.error('Missing Jira credentials:', { 
        hasEmail: !!jiraEmail, 
        hasToken: !!jiraToken 
      });
      res.status(500).json({ 
        error: 'Jira credentials not configured',
        details: 'Missing email or API token'
      });
      return;
    }

    console.log('Credentials loaded:', { 
      email: jiraEmail,
      tokenLength: jiraToken?.length,
      baseUrl: JIRA_API_BASE
    });

    const auth = Buffer.from(`${jiraEmail}:${jiraToken}`).toString('base64');
    const url = `${JIRA_API_BASE}/rest/api/2/issue/${storyId}`;
    
    console.log('URL:', url);
    const response = await axios.get<JiraResponse>(url, {
      headers: {
        'Authorization': `Basic ${auth}`,
        'Accept': 'application/json'
      }
    });

    const story = {
      storyTitle: response.data.fields?.summary || '',
      description: response.data.fields?.description || '',
      acceptanceCriteria: response.data.fields?.customfield_10016 || '',
      additionalInfo: response.data.fields?.customfield_10017 || '',
      category: ''
    };

    res.json(story);
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error('API Error:', {
        status: error.response?.status,
        data: error.response?.data,
        message: error.message
      });

      res.status(error.response?.status || 500).json({
        error: 'Failed to fetch story',
        details: error.message,
        response: error.response?.data
      });
    } else {
      console.error('Unexpected error:', error);
      res.status(500).json({
        error: 'Internal server error',
        details: 'An unexpected error occurred'
      });
    }
  }
});